### 常见问题

**Git 地址**: [项目地址，完全开源，随便用。](https://github.com/c121914yu/FastGPT)
**问题文档**: [先看文档，再提问](https://kjqvjse66l.feishu.cn/docx/HtrgdT0pkonP4kxGx8qcu6XDnGh)  
**价格表**
如果使用了自己的 Api Key，网页上 openai 模型聊天不会计费。可以在账号页，看到详细账单。
| 计费项 | 价格: 元/ 1K tokens（包含上下文）|
| --- | --- |
| 知识库 - 索引 | 0.001 |
| chatgpt - 对话 | 0.015 |
| chatgpt16K - 对话 | 0.03 |
| 窝牛 GPT4 不稳定 - 对话 | 0.015 |
| gpt4 - 对话 | 0.45 |
| 文件拆分 | 0.03 |

**其他问题**
| 交流群 | 小助手 |
| ----------------------- | -------------------- |
| ![](https://otnvvf-imgs.oss.laf.run/wxqun300.jpg) | ![](https://otnvvf-imgs.oss.laf.run/wx300.jpg) |
