### Fast GPT V3.9

1. 新增 - 直接分段训练，可调节段落大小。
2. 优化 - tokens 计算性能。
3. 优化 - key 池管理，结合 one-api 项目，实现更方便的 key 池管理，具体参考[docker 部署 FastGpt](https://github.com/c121914yu/FastGPT/blob/main/docs/deploy/docker.md)
4. 新增 - V2 版 OpenAPI，可以在任意第三方套壳 ChatGpt 项目中直接使用 FastGpt 的应用，注意！是直接，不需要改任何代码。具体参考[API 文档中《在第三方应用中使用 FastGpt》](https://kjqvjse66l.feishu.cn/docx/DmLedTWtUoNGX8xui9ocdUEjnNh)
